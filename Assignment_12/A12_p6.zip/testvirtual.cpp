/*
CH-230-A
a12_p6.cpp
Yen Ling Wong
ywong@jacobs-university.de
*/

#include <iostream>
using namespace std;

#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"
#include "Square.h"
 
const int num_obj = 7;

int main() {
	Area *list[num_obj];						// (1)
    // Objects of different but related classes (ring, circle, etc) are referred to 
    // using (Area *) as a pointer to the base class Area. 
    // This is initialized as an array named list, which has 7 elements inside.

	int index = 0;								// (2)
    // Initializing a counter of type integer to be used later in a while loop.
    int index2 = 0;

	double sum_area = 0.0;						// (3)
    // Initializing a double variable to store the total area of all instances.

    double sum_perimeter = 0.0;

	cout << "Creating Ring: ";
	Ring blue_ring("BLUE", 5, 2);				// (4)
    // An instance of class Ring is declared using a parametric constructor.
    // The terminal outputs "Creating Ring: Area constructor being called..."
    // This is because Ring is an inheritance of Circle, which in turn
    // Is an inheritance of class Area
    // Therefore, the area constructor is called and prints the corresponding message

	cout << "Creating Circle: ";
	Circle yellow_circle("YELLOW", 7);

	cout << "Creating Rectangle: ";
	Rectangle green_rectangle("GREEN",5,6);

	cout << "Creating Circle: ";
	Circle red_circle("RED", 8);

	cout << "Creating Rectangle: ";
	Rectangle black_rectangle("BLACK", 10, 20);

	cout << "Creating Ring: ";
	Ring violet_ring("VIOLET", 100, 5);

    cout << "Creating Square: ";
    Square white_square("WHITE", 3, 46, 57);
    // Creating an Instance of Square

	list[0] = &blue_ring;						// (5)
    // The first element of the array is assigned the address of
    // An object of class Ring. Such an assignment is valid, since 
    // Ring is derived from class Area.

	list[1] = &yellow_circle;
	list[2] = &green_rectangle;
	list[3] = &red_circle;
	list[4] = &black_rectangle;
	list[5] = &violet_ring;
    list[6] = &white_square;

	while (index < num_obj) {					// (7)
    // While loop to iterate through the array

		(list[index])->getColor();				
		double area = list[index++]->calcArea();// (8)
        // The colour of each element of the array
        // Is accessed with the getColor() function
        // As such, the corresponding message is printed 
        // because of cout << "\n" << color << ": ";
        // in the Area base class. 
        // A double variable is declared to store the area of each 
        // Object which is accessed through calcArea.
        // The corresponding message is printed because because 
        // calcArea is being called to compute the area.
        // This is valid because calcArea is declared as virtual 
        // to prevent static linkage so that the function may be defined
        // Again in the other classes
        // Index++ increments each iteration

		sum_area += area;
	}

    cout << endl;

    while (index2 < num_obj) {	
        (list[index2])->getColor();
        double perimeter = list[index2++]->calcPerimeter();
        sum_perimeter += perimeter;
    }
    cout << endl;

	cout << "\nThe total area is "
			<< sum_area << " units^2 " << endl;	// (9)
            // The total area is calculated in the while loop above
            // This value is stored in sum area.

    cout << "The total perimeter is "
			<< sum_perimeter << " units " << endl;	// (9)
    cout << endl;
	return 0;
}

// INHERITANCE DIAGRAM

//          _________
//         |  AREA   |
//      ---|_________| ---        
//     |                  |
//     |                  |
// _________         ______________
//| CIRCLE  |       |  RECTANGLE   |
//|_________|       |______________|
//     |                   |
//     |                   |
// _________          ___________
//|  RING   |        |   SQUARE  |
//|_________|        |___________|
